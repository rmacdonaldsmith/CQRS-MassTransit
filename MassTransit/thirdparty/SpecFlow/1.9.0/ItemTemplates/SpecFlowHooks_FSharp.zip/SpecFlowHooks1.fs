﻿[<TechTalk.SpecFlow.Binding>]
module $safeitemname$

open TechTalk.SpecFlow

// For additional details on SpecFlow hooks see http://go.specflow.org/doc-hooks

let [<BeforeScenario>] BeforeScenario() = 
    () //TODO: implement logic that has to run before executing each scenario

let [<AfterScenario>] AfterScenario() = 
    () //TODO: implement logic that has to run after executing each scenario

