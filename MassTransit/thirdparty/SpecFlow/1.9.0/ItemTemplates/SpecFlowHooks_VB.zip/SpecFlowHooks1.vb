﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports TechTalk.SpecFlow

Namespace $rootnamespace$

    <Binding()> _
    Public Class $safeitemname$

        'For additional details on SpecFlow hooks see http://go.specflow.org/doc-hooks

        <BeforeScenario()> _
        Public Sub BeforeScenario()
            'TODO: implement logic that has to run before executing each scenario
        End Sub

        <AfterScenario()> _
        Public Sub AfterScenario()
            'TODO: implement logic that has to run after executing each scenario
        End Sub

    End Class

End Namespace
